# Karlok Android (ir.karlok)
Native Kotlin shell + WebView for https://karlok.ir
- Build: push to GitHub, run Actions "Build APK". Secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS (key0), KEY_PASSWORD.
- Local: ./gradlew assembleRelease (set KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD env vars to sign).
- Raise versionCode in app/build.gradle.kts for every store update.
