# default rules are enough (no reflection / JS interfaces)
-keepattributes *Annotation*
-keepclassmembers class ir.karlok.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
