package ir.karlok

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

/**
 * Karlok Native Bridge, contract v1 (see kva-native.js in the Karlok Voice Assistant plugin).
 * Only the capabilities listed in getCapabilities() are implemented; the plugin discovers them at run time.
 * Every method answers only while the page shown belongs to karlok.ir.
 */
class NativeBridge(
    private val activity: MainActivity,
    private val webView: WebView,
    private val trusted: () -> Boolean
) {
    private val ui = Handler(Looper.getMainLooper())
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val state = when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> "gain"
            AudioManager.AUDIOFOCUS_LOSS -> "loss"
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> "transient"
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> "duck"
            else -> null
        }
        if (state != null) dispatch("audioFocus", "{\"state\":\"" + state + "\"}")
    }

    @JavascriptInterface
    fun getCapabilities(): String {
        if (!trusted()) return "{}"
        return "{\"contract\":1,\"platform\":\"android\",\"app\":\"2.0.0\"," +
            "\"capabilities\":[\"mic.permission\",\"audio.session\",\"audio.release\",\"network\"]}"
    }

    @JavascriptInterface
    fun micPermission(args: String?): String {
        if (!trusted()) return "{}"
        val state = if (activity.has(android.Manifest.permission.RECORD_AUDIO)) "granted" else "prompt"
        return "{\"state\":\"" + state + "\"}"
    }

    @JavascriptInterface
    fun requestMicPermission(args: String?) {
        if (!trusted()) return
        ui.post {
            activity.requestMic { granted ->
                dispatch("permission", "{\"state\":\"" + (if (granted) "granted" else "denied") + "\"}")
            }
        }
    }

    @JavascriptInterface
    fun setAudioMode(args: String?) {
        if (!trusted()) return
        val mode = try {
            JSONObject(args ?: "{}").optString("mode", "media")
        } catch (e: Exception) {
            "media"
        }
        ui.post { if (mode == "voice") requestFocus() else abandonFocus() }
    }

    @JavascriptInterface
    fun releaseAudio(args: String?) {
        if (!trusted()) return
        ui.post { abandonFocus() }
    }

    @JavascriptInterface
    fun networkState(args: String?): String {
        if (!trusted()) return "{}"
        val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val type = when {
            !online || caps == null -> "none"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
            else -> "other"
        }
        return "{\"online\":" + online + ",\"type\":\"" + type + "\"}"
    }

    /** Sends an event to the page: window.KarlokNativeBridge.dispatch(type, payload). payload must be JSON built by the app. */
    fun dispatch(type: String, payloadJson: String) {
        val js = "window.KarlokNativeBridge&&window.KarlokNativeBridge.dispatch(" +
            JSONObject.quote(type) + "," + payloadJson + ")"
        ui.post { if (trusted()) webView.evaluateJavascript(js, null) }
    }

    fun release() = abandonFocus()

    private fun requestFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusRequest != null) return
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            focusRequest = req
            audio.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audio.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        }
    }

    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { audio.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            audio.abandonAudioFocus(focusListener)
        }
    }
}
