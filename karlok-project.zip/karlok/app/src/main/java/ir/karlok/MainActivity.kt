package ir.karlok

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var offline: View
    private lateinit var loading: View

    private var hadError = false
    private var lastUrl = HOME
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var pendingMic: PermissionRequest? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private lateinit var bridge: NativeBridge
    @Volatile private var trustedPage = false
    private var micCallback: ((Boolean) -> Unit)? = null

    private val bridgeMicLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            micCallback?.invoke(granted)
            micCallback = null
        }

    fun requestMic(cb: (Boolean) -> Unit) {
        if (has(Manifest.permission.RECORD_AUDIO)) {
            cb(true)
        } else {
            micCallback = cb
            bridgeMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val result = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }

    private val geoLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val ok = res[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                res[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            geoCallback?.invoke(geoOrigin, ok, false)
            geoCallback = null
            geoOrigin = null
        }

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val req = pendingMic
            pendingMic = null
            if (req != null) {
                if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else req.deny()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // warm the OS DNS cache while the UI is being built
        Thread { try { java.net.InetAddress.getAllByName("karlok.ir") } catch (e: Exception) { } }.start()
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progress = findViewById(R.id.progress)
        offline = findViewById(R.id.offline)
        loading = findViewById(R.id.loading)
        loading.postDelayed({ hideLoading() }, 10000)
        findViewById<View>(R.id.retryButton).setOnClickListener { retry() }

        setupWebView()
        bridge = NativeBridge(this, webView) { trustedPage }
        webView.addJavascriptInterface(bridge, "KarlokNative")
        watchNetwork()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val restored = savedInstanceState?.let { webView.restoreState(it) }
        if (restored == null) webView.loadUrl(startUrl(intent))
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.data != null) webView.loadUrl(startUrl(intent))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.setBackgroundColor(Color.WHITE)
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        // images over http (passive content) are allowed; scripts/iframes over http stay blocked
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.setGeolocationEnabled(true)
        s.userAgentString = s.userAgentString + " KarlokApp/2.0"

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null || !request.isForMainFrame) return false
                return handleUrl(request.url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                hadError = false
                trustedPage = url != null && isKarlokHost(Uri.parse(url).host)
                progress.visibility = View.VISIBLE
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                hideLoading()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                hideLoading()
                if (!hadError) {
                    offline.visibility = View.GONE
                    if (url != null) lastUrl = url
                }
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame) {
                    hadError = true
                    lastUrl = request.url.toString()
                    showOffline()
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel() // never bypass certificate validation
                hadError = true
                showOffline()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress >= 100) progress.visibility = View.GONE
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    filePathCallback.onReceiveValue(null)
                    false
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (origin == null || callback == null) return
                if (!isKarlokHost(Uri.parse(origin).host)) {
                    callback.invoke(origin, false, false)
                    return
                }
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    geoLauncher.launch(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (!wantsAudio || !isKarlokHost(request.origin.host)) {
                    request.deny()
                    return
                }
                if (has(Manifest.permission.RECORD_AUDIO)) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    pendingMic?.deny()
                    pendingMic = request
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                if (request == pendingMic) pendingMic = null
            }
        }
    }

    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        return when (scheme) {
            "https" -> if (!isKarlokHost(uri.host) && isMapLink(uri)) openExternal(uri) else false
            "http" -> {
                webView.loadUrl(uri.buildUpon().scheme("https").build().toString())
                true
            }
            "about", "blob", "data", "javascript" -> false
            "intent" -> openIntentUri(uri.toString())
            else -> openExternal(uri) // tel, mailto, sms, geo, google.navigation, market, ...
        }
    }

    private fun isMapLink(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path.orEmpty()
        return host == "maps.google.com" ||
            host == "maps.app.goo.gl" ||
            ((host == "www.google.com" || host == "google.com") && path.startsWith("/maps")) ||
            host == "waze.com" || host == "www.waze.com" ||
            host == "neshan.org" || host == "nshn.ir" || host == "balad.ir"
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            if (uri.scheme.equals("https", true)) {
                false // no app handled it: load in the WebView instead
            } else {
                Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    private fun openIntentUri(url: String): Boolean {
        return try {
            val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
            true
        } catch (e: Exception) {
            val fb = try {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url")
            } catch (e2: Exception) {
                null
            }
            if (fb != null && fb.startsWith("https://")) webView.loadUrl(fb)
            true
        }
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, cd, mime)
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        fun request() = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mime)
            setTitle(name)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
            if (ua != null) addRequestHeader("User-Agent", ua)
        }
        try {
            dm.enqueue(request().apply {
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            })
        } catch (e: SecurityException) {
            dm.enqueue(request().apply {
                setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, name)
            })
        } catch (e: Exception) {
            return
        }
        Toast.makeText(this, R.string.downloading, Toast.LENGTH_SHORT).show()
    }

    private fun watchNetwork() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                bridge.dispatch("network", "{\"online\":true}")
                runOnUiThread { if (offline.visibility == View.VISIBLE) retry() }
            }

            override fun onLost(network: Network) {
                bridge.dispatch("network", "{\"online\":false}")
            }
        }
        try {
            cm.registerDefaultNetworkCallback(cb)
            netCallback = cb
        } catch (e: Exception) {
            // best effort; the retry button still works
        }
    }

    private fun hideLoading() {
        if (loading.visibility != View.VISIBLE) return
        loading.animate().alpha(0f).setDuration(150).withEndAction { loading.visibility = View.GONE }.start()
    }

    private fun showOffline() {
        hideLoading()
        progress.visibility = View.GONE
        offline.visibility = View.VISIBLE
    }

    private fun retry() {
        offline.visibility = View.GONE
        hadError = false
        webView.loadUrl(lastUrl)
    }

    private fun startUrl(i: Intent?): String {
        val d = i?.data
        return if (d != null && d.scheme == "https" && isKarlokHost(d.host)) d.toString() else HOME
    }

    fun has(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        bridge.dispatch("lifecycle", "{\"state\":\"foreground\"}")
    }

    override fun onPause() {
        bridge.dispatch("lifecycle", "{\"state\":\"background\"}")
        webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        netCallback?.let {
            try {
                (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it)
            } catch (e: Exception) {
            }
        }
        bridge.release()
        fileCallback?.onReceiveValue(null)
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val HOME = "https://karlok.ir"

        fun isKarlokHost(host: String?): Boolean {
            val h = host?.lowercase() ?: return false
            return h == "karlok.ir" || h.endsWith(".karlok.ir")
        }
    }
}
